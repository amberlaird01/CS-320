package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactTest {

	@Test
	void testContact() {
	    Contact contact = new Contact("12345", "Amber", "Laird",
	            "7175551234", "123 Main Street");

	    assertEquals("12345", contact.getContactID());
	    assertEquals("Amber", contact.getFirstName());
	    assertEquals("Laird", contact.getLastName());
	    assertEquals("7175551234", contact.getPhone());
	    assertEquals("123 Main Street", contact.getAddress());
	}
	
	@Test
	void testContactIDTooLong() {
	    assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("12345678901", "Amber", "Laird",
	                "7175551234", "123 Main Street");
	    });
	}
	
	@Test
	void testContactIDNull() {
	    assertThrows(IllegalArgumentException.class, () -> {
	        new Contact(null, "Amber", "Laird",
	                "7175551234", "123 Main Street");
	    });
	}
	
	@Test
	void testFirstNameTooLong() {
	    assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("12345", "Christopher", "Laird",
	                "7175551234", "123 Main Street");
	    });
	}
	
	@Test
	void testFirstNameNull() {
	    assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("12345", null, "Laird",
	                "7175551234", "123 Main Street");
	    });
	}
	
	@Test
	void testLastNameTooLong() {
	    assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("12345", "Amber", "VeryLongLastName",
	                "7175551234", "123 Main Street");
	    });
	}
	
	@Test
	void testLastNameNull() {
	    assertThrows(IllegalArgumentException.class, () -> {
	        new Contact("12345", "Amber", null,
	                "7175551234", "123 Main Street");
	    });
	}
}
