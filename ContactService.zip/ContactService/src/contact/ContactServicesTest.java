package contact;

import static org.junit.jupiter.api.Assertions.*;

import org.junit.jupiter.api.Test;

class ContactServicesTest {

	@Test
	void testAddContact() {
	    ContactService service = new ContactService();

	    Contact contact = new Contact("12345", "Amber", "Laird",
	            "7175551234", "123 Main Street");

	    assertDoesNotThrow(() -> service.addContact(contact));
	}

	@Test
	void testDuplicateContactID() {
	    ContactService service = new ContactService();

	    Contact contact1 = new Contact("12345", "Amber", "Laird",
	            "7175551234", "123 Main Street");

	    Contact contact2 = new Contact("12345", "John", "Smith",
	            "7175555678", "456 Main Street");

	    service.addContact(contact1);

	    assertThrows(IllegalArgumentException.class, () -> {
	        service.addContact(contact2);
	    });
	}
	
	@Test
	void testDeleteContact() {
	    ContactService service = new ContactService();

	    Contact contact = new Contact("12345", "Amber", "Laird",
	            "7175551234", "123 Main Street");

	    service.addContact(contact);
	    service.deleteContact("12345");

	    assertThrows(IllegalArgumentException.class, () -> {
	        service.deleteContact("12345");
	    });
	}
	
	@Test
	void testUpdateContact() {
	    ContactService service = new ContactService();

	    Contact contact = new Contact("12345", "Amber", "Laird",
	            "7175551234", "123 Main Street");

	    service.addContact(contact);

	    service.updateContact("12345", "Amy", "Smith",
	            "7175559999", "456 Oak Street");

	    assertEquals("Amy", contact.getFirstName());
	    assertEquals("Smith", contact.getLastName());
	    assertEquals("7175559999", contact.getPhone());
	    assertEquals("456 Oak Street", contact.getAddress());
	}
	
	@Test
	void testUpdateContactNotFound() {
	    ContactService service = new ContactService();

	    assertThrows(IllegalArgumentException.class, () -> {
	        service.updateContact("99999", "Amy", "Smith",
	                "7175559999", "456 Oak Street");
	    });
	}

}
