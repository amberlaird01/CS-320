package contact;

import java.util.ArrayList;

public class ContactService {
	
	private ArrayList<Contact> contacts = new ArrayList<Contact>();
	
	public void addContact(Contact contact) {
	    for (Contact existingContact : contacts) {
	        if (existingContact.getContactID().equals(contact.getContactID())) {
	            throw new IllegalArgumentException("Contact ID already exists");
	        }
	    }

	    contacts.add(contact);
	}
	
	public void deleteContact(String contactID) {
	    for (Contact contact : contacts) {
	        if (contact.getContactID().equals(contactID)) {
	            contacts.remove(contact);
	            return;
	        }
	    }

	    throw new IllegalArgumentException("Contact ID not found");
	}
	
	public void updateContact(String contactID, String firstName,
	        String lastName, String phone, String address) {

	    for (Contact contact : contacts) {
	        if (contact.getContactID().equals(contactID)) {
	            contact.setFirstName(firstName);
	            contact.setLastName(lastName);
	            contact.setPhone(phone);
	            contact.setAddress(address);
	            return;
	        }
	    }

	    throw new IllegalArgumentException("Contact ID not found");
	}

}
